import java.util.Scanner;

public class Blackjack {

    public Scanner info = new Scanner(System.in); // can I make it private?


    public void initialization(Deck card) {

    }
}
